﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cubo3d_el_bueno
{

    public class Figure
    {
        public List<PointF> Pts;

        public Figure()
        {
            Pts = new List<PointF>();
        }
    }
}
