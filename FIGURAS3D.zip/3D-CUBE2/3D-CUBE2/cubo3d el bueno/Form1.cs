﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Net.Mime.MediaTypeNames;
using System.Numerics;


namespace cubo3d_el_bueno
{
    public partial class Form1 : Form
    {

        Bitmap bmp;
        Graphics g;
        private Point l1, l2, l3, l4;
        private int width, height, wMid, hMid;
        private Point origen;
       
        Matrix projectionMatrix = new Matrix();
      


        double angle = 0;
        double angleConverted;

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = false;
            timer3.Enabled = false;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer2.Enabled = true;
            timer1.Enabled = false;
            timer3.Enabled = false;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;
            timer2.Enabled = false;
            timer1.Enabled = false;
        }


        private void Form1_Load(object sender, EventArgs e)
        {
           
        }        
        private void timer1_Tick(object sender, EventArgs e)
        {
            angle -= 1;
            angleConverted = angle * (Math.PI / 180);

            InitializePictureBox(width, height);

            //Generate Cylinder Points

            double Cylinderradius = 1.5;
            double Cylinderheight = 3.0;
            int cylinderDetail = 50;
            List<double[]> cylinderPoints = new List<double[]>();

            // Generar los puntos de la superficie curva del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);

                for (int j = 0; j <= cylinderDetail; j++)
                {
                    double z = Cylinderheight * (double)j / cylinderDetail - Cylinderheight / 2.0;

                    double[] point = new double[] { x, y, z };
                    cylinderPoints.Add(point);
                }
            }

            // Generar los puntos del disco inferior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = -Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            // Generar los puntos del disco superior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            //CYLINDER?
            List<double[]> rotatedCylinderPoints = new List<double[]>();
            foreach (double[] point in cylinderPoints)
            {
                double[] rotatedCylinderPoint = projectionMatrix.rotationX(point, angleConverted);
                rotatedCylinderPoints.Add(rotatedCylinderPoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedCylinderPoints = new List<PointF>();
            foreach (double[] point in rotatedCylinderPoints)
            {
                double[] projectedCylinderPoint = projectionMatrix.multiply(point, 3);
                PointF projectedCylinderPointF = new PointF((float)(projectedCylinderPoint[0] * 100), (float)(projectedCylinderPoint[1] * 100));
                projectedCylinderPoints.Add(projectedCylinderPointF);
            }
            //DrawCylinder
            for (int i = 0; i < cylinderDetail; i++)
            {
                for (int j = 0; j < cylinderDetail; j++)
                {
                    int p1 = i * (cylinderDetail + 1) + j;
                    int p2 = p1 + 1;
                    int p3 = (i + 1) * (cylinderDetail + 1) + j;
                    int p4 = p3 + 1;

                    
                    
                    //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p2], 0);
                    
                    //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);

                    //if (j == 0)
                    //{
                        //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2], 0);
                        //Render(projectedCylinderPoints[p2], projectedCylinderPoints[p2 + cylinderDetail],0);
                        //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p2 + cylinderDetail], projectedCylinderPoints[p1 + cylinderDetail],0);
                    //}
                    //else if (j == cylinderDetail - 1)
                    //{
                        //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);
                        //Render(projectedCylinderPoints[p4], projectedCylinderPoints[p4 + cylinderDetail],0);
                        //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p4 + cylinderDetail], projectedCylinderPoints[p3 + cylinderDetail],0);
                    //}
                }
            }


            //Generate CONE Points
            double Coneradius = 1.5;
            double Coneheight = 2.5;
            int coneDetail = 50;
            List<double[]> conePoints = new List<double[]>();

            for (int i = 0; i <= coneDetail; i++)
            {
                double angle = 2 * Math.PI * (double)i / coneDetail;
                double x = Coneradius * (1 - (double)i / coneDetail) * Math.Cos(angle);
                double y = Coneradius * (1 - (double)i / coneDetail) * Math.Sin(angle);
                double z = Coneheight * ((double)i / coneDetail) - Coneheight / 2;

                double[] point = new double[] { x, y, z };
                conePoints.Add(point);
            }
            //CONE?
            List<double[]> rotatedConePoints = new List<double[]>();
            foreach (double[] point in conePoints)
            {
                double[] rotatedConePoint = projectionMatrix.rotationX(point, angleConverted);
                rotatedConePoints.Add(rotatedConePoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedConePoints = new List<PointF>();
            foreach (double[] point in rotatedConePoints)
            {
                double[] projectedConePoint = projectionMatrix.multiply(point, 3);
                PointF projectedConePointF = new PointF((float)(projectedConePoint[0] * 100), (float)(projectedConePoint[1] * 100));
                projectedConePoints.Add(projectedConePointF);
            }
            //DrawCone
            for (int i = 0; i < conePoints.Count; i++)
            {
                int p1 = i;
                int p2 = (i + 1) % conePoints.Count;
                int p3 = conePoints.Count - 1;

                //Render(projectedConePoints[p1], projectedConePoints[p2], 0);
                //Render(projectedConePoints[p2], projectedConePoints[p3], 0);
                //Render(projectedConePoints[p3], projectedConePoints[p1], 0);

            }


            // Generate SPHERE Points
            double radius = 1.5;
            int sphereDetail = 50;
            List<double[]> spherePoints = new List<double[]>();

            for (int i = 0; i <= sphereDetail; i++)
            {
                double lat = Math.PI * (-0.5 + (double)(i - 1) / sphereDetail);
                double z = radius * Math.Sin(lat);
                double xy = radius * Math.Cos(lat);

                for (int j = 0; j <= sphereDetail; j++)
                {
                    double lng = 2 * Math.PI * (double)(j - 1) / sphereDetail;
                    double x = xy * Math.Cos(lng);
                    double y = xy * Math.Sin(lng);

                    double[] point = new double[] { x, y, z };
                    spherePoints.Add(point);
                }
            }

            //SPHERE?
            List<double[]> rotatedSpherePoints = new List<double[]>();
            foreach (double[] point in spherePoints)
            {
                double[] rotatedSpherePoint = projectionMatrix.rotationX(point, angleConverted);
                rotatedSpherePoints.Add(rotatedSpherePoint);
            }
            // Project SPHERE? points onto 2D plane
            List<PointF> projectedSpherePoints = new List<PointF>();
            foreach (double[] point in rotatedSpherePoints)
            {
                double[] projectedSpherePoint = projectionMatrix.multiply(point, 3);
                PointF projectedSpherePointF = new PointF((float)(projectedSpherePoint[0] * 100), (float)(projectedSpherePoint[1] * 100));
                projectedSpherePoints.Add(projectedSpherePointF);
            }
            //DrawSphere
            //for (int i = 0; i < sphereDetail; i++)
            //{
                //for (int j = 0; j < sphereDetail; j++)
                //{
                    //int p1 = i * sphereDetail + j;
                    //int p2 = (i + 1) % sphereDetail * sphereDetail + j;
                    //int p3 = (i + 1) % sphereDetail * sphereDetail + (j + 1) % sphereDetail;
                    //int p4 = i * sphereDetail + (j + 1) % sphereDetail;

                    //Render(projectedSpherePoints[p1], projectedSpherePoints[p2], 0);
                    //Render(projectedSpherePoints[p2], projectedSpherePoints[p3], 0);
                    //Render(projectedSpherePoints[p3], projectedSpherePoints[p4], 0);
                    //Render(projectedSpherePoints[p4], projectedSpherePoints[p1], 0);
                //}
            //}

            // Generate torus points
            double R = 1.5;
            double r = 0.5;
            int torusDetail = 50;
            List<double[]> torusPoints = new List<double[]>();
            for (int i = 0; i < torusDetail; i++)
            {
                double theta = i * 2 * Math.PI / torusDetail;
                for (int j = 0; j < torusDetail; j++)
                {
                    double phi = j * 2 * Math.PI / torusDetail;
                    double x = (R + r * Math.Cos(phi)) * Math.Cos(theta);
                    double y = (R + r * Math.Cos(phi)) * Math.Sin(theta);
                    double z = r * Math.Sin(phi);
                    double[] point = new double[] { x, y, z };
                    torusPoints.Add(point);
                }
            }

            // Rotate torus points around X-axis
            List<double[]> rotatedTorusPoints = new List<double[]>();
            foreach (double[] point in torusPoints)
            {
                double[] rotatedPoint = projectionMatrix.rotationX(point, angleConverted);
                rotatedTorusPoints.Add(rotatedPoint);
            }
           
            // Project torus points onto 2D plane
            List<PointF> projectedTorusPoints = new List<PointF>();
            foreach (double[] point in rotatedTorusPoints)
            {
                double[] projectedPoint = projectionMatrix.multiply(point, 3);
                PointF projectedPointF = new PointF((float)(projectedPoint[0] * 100), (float)(projectedPoint[1] * 100));
                projectedTorusPoints.Add(projectedPointF);
            }
           

            // Draw torus
            for (int i = 0; i < torusDetail; i++)
            {
                for (int j = 0; j < torusDetail; j++)
                {
                    int p1 = i * torusDetail + j;
                    int p2 = (i + 1) % torusDetail * torusDetail + j;
                    int p3 = (i + 1) % torusDetail * torusDetail + (j + 1) % torusDetail;
                    int p4 = i * torusDetail + (j + 1) % torusDetail;

                    Render(projectedTorusPoints[p1], projectedTorusPoints[p2], 0);
                    Render(projectedTorusPoints[p2], projectedTorusPoints[p3], 0);
                    //FillTriangle(projectedTorusPoints[p1], projectedTorusPoints[p2], projectedTorusPoints[p3], Color.Green);
                    Render(projectedTorusPoints[p3], projectedTorusPoints[p4], 0);
                    //FillTriangle(projectedTorusPoints[p3], projectedTorusPoints[p4], projectedTorusPoints[p1], Color.Green);
                    Render(projectedTorusPoints[p4], projectedTorusPoints[p1], 0);
                }
            }
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            angle -= 1;
            angleConverted = angle * (Math.PI / 180);

            InitializePictureBox(width, height);

            //Generate CONE Points
            double Coneradius = 1.5;
            double Coneheight = 2.5;
            int coneDetail = 50;
            List<double[]> conePoints = new List<double[]>();

            for (int i = 0; i <= coneDetail; i++)
            {
                double angle = 2 * Math.PI * (double)i / coneDetail;
                double x = Coneradius * (1 - (double)i / coneDetail) * Math.Cos(angle);
                double y = Coneradius * (1 - (double)i / coneDetail) * Math.Sin(angle);
                double z = Coneheight * ((double)i / coneDetail) - Coneheight / 2;

                double[] point = new double[] { x, y, z };
                conePoints.Add(point);
            }
            //CONE?
            List<double[]> rotatedConePoints = new List<double[]>();
            foreach (double[] point in conePoints)
            {
                double[] rotatedConePoint = projectionMatrix.RotationY(point, angleConverted);
                rotatedConePoints.Add(rotatedConePoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedConePoints = new List<PointF>();
            foreach (double[] point in rotatedConePoints)
            {
                double[] projectedConePoint = projectionMatrix.multiply(point, 3);
                PointF projectedConePointF = new PointF((float)(projectedConePoint[0] * 100), (float)(projectedConePoint[1] * 100));
                projectedConePoints.Add(projectedConePointF);
            }
            //DrawCone
            //for (int i = 0; i < conePoints.Count; i++)
            //{
            //int p1 = i;
            //int p2 = (i + 1) % conePoints.Count;
            //int p3 = conePoints.Count - 1;

            //Render(projectedConePoints[p1], projectedConePoints[p2], 0);
            //Render(projectedConePoints[p2], projectedConePoints[p3], 0);
            //Render(projectedConePoints[p3], projectedConePoints[p1], 0);

            //}


            //Generate Cylinder Points

            double Cylinderradius = 1.5;
            double Cylinderheight = 3.0;
            int cylinderDetail = 50;
            List<double[]> cylinderPoints = new List<double[]>();

            // Generar los puntos de la superficie curva del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);

                for (int j = 0; j <= cylinderDetail; j++)
                {
                    double z = Cylinderheight * (double)j / cylinderDetail - Cylinderheight / 2.0;

                    double[] point = new double[] { x, y, z };
                    cylinderPoints.Add(point);
                }
            }

            // Generar los puntos del disco inferior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = -Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            // Generar los puntos del disco superior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            //CYLINDER?
            List<double[]> rotatedCylinderPoints = new List<double[]>();
            foreach (double[] point in cylinderPoints)
            {
                double[] rotatedCylinderPoint = projectionMatrix.RotationY(point, angleConverted);
                rotatedCylinderPoints.Add(rotatedCylinderPoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedCylinderPoints = new List<PointF>();
            foreach (double[] point in rotatedCylinderPoints)
            {
                double[] projectedCylinderPoint = projectionMatrix.multiply(point, 3);
                PointF projectedCylinderPointF = new PointF((float)(projectedCylinderPoint[0] * 100), (float)(projectedCylinderPoint[1] * 100));
                projectedCylinderPoints.Add(projectedCylinderPointF);
            }
            //DrawCylinder
            //for (int i = 0; i < cylinderDetail; i++)
            //{
                //for (int j = 0; j < cylinderDetail; j++)
                //{
                    //int p1 = i * (cylinderDetail + 1) + j;
                    //int p2 = p1 + 1;
                    //int p3 = (i + 1) * (cylinderDetail + 1) + j;
                    //int p4 = p3 + 1;

                    //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p3], 0);
                    //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p2], 0);
                    //Render(projectedCylinderPoints[p2], projectedCylinderPoints[p3], 0);
                    //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);

                    //if (j == 0)
                    //{
                        //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2], 0);
                        //Render(projectedCylinderPoints[p2], projectedCylinderPoints[p2 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p2 + cylinderDetail], projectedCylinderPoints[p1 + cylinderDetail], 0);
                    //}
                    //else if (j == cylinderDetail - 1)
                    //{
                        //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);
                        //Render(projectedCylinderPoints[p4], projectedCylinderPoints[p4 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4 + cylinderDetail], 0);
                        //Render(projectedCylinderPoints[p4 + cylinderDetail], projectedCylinderPoints[p3 + cylinderDetail], 0);
                    //}
                //}
            //}


            // Generate SPHERE Points
            double radius = 1.5;
            int sphereDetail = 50;
            List<double[]> spherePoints = new List<double[]>();

            for (int i = 0; i <= sphereDetail; i++)
            {
                double lat = Math.PI * (-0.5 + (double)(i - 1) / sphereDetail);
                double z = radius * Math.Sin(lat);
                double xy = radius * Math.Cos(lat);

                for (int j = 0; j <= sphereDetail; j++)
                {
                    double lng = 2 * Math.PI * (double)(j - 1) / sphereDetail;
                    double x = xy * Math.Cos(lng);
                    double y = xy * Math.Sin(lng);

                    double[] point = new double[] { x, y, z };
                    spherePoints.Add(point);
                }
            }

            //SPHERE?
            List<double[]> rotatedSpherePoints = new List<double[]>();
            foreach (double[] point in spherePoints)
            {
                double[] rotatedSpherePoint = projectionMatrix.RotationY(point, angleConverted);
                rotatedSpherePoints.Add(rotatedSpherePoint);
            }
            // Project SPHERE? points onto 2D plane
            List<PointF> projectedSpherePoints = new List<PointF>();
            foreach (double[] point in rotatedSpherePoints)
            {
                double[] projectedSpherePoint = projectionMatrix.multiply(point, 3);
                PointF projectedSpherePointF = new PointF((float)(projectedSpherePoint[0] * 100), (float)(projectedSpherePoint[1] * 100));
                projectedSpherePoints.Add(projectedSpherePointF);
            }
            //DrawSphere
            for (int i = 0; i < sphereDetail; i++)
            {
                for (int j = 0; j < sphereDetail; j++)
                {
                    int p1 = i * sphereDetail + j;
                    int p2 = (i + 1) % sphereDetail * sphereDetail + j;
                    int p3 = (i + 1) % sphereDetail * sphereDetail + (j + 1) % sphereDetail;
                    int p4 = i * sphereDetail + (j + 1) % sphereDetail;

                    Render(projectedSpherePoints[p1], projectedSpherePoints[p2], 0);
                    //FillTriangle(projectedSpherePoints[p1], projectedSpherePoints[p2], projectedSpherePoints[p3], Color.Purple);
                    Render(projectedSpherePoints[p2], projectedSpherePoints[p3], 0);
                    Render(projectedSpherePoints[p3], projectedSpherePoints[p4], 0);
                    //FillTriangle(projectedSpherePoints[p3], projectedSpherePoints[p4], projectedSpherePoints[p1], Color.Purple);
                    Render(projectedSpherePoints[p4], projectedSpherePoints[p1], 0);
                }
            }

            // Generate torus points
            double R = 1.5;
            double r = 0.5;
            int torusDetail = 50;
            List<double[]> torusPoints = new List<double[]>();
            for (int i = 0; i < torusDetail; i++)
            {
                double theta = i * 2 * Math.PI / torusDetail;
                for (int j = 0; j < torusDetail; j++)
                {
                    double phi = j * 2 * Math.PI / torusDetail;
                    double x = (R + r * Math.Cos(phi)) * Math.Cos(theta);
                    double y = (R + r * Math.Cos(phi)) * Math.Sin(theta);
                    double z = r * Math.Sin(phi);
                    double[] point = new double[] { x, y, z };
                    torusPoints.Add(point);
                }
            }

            // Rotate torus points around Y-axis
            List<double[]> rotatedTorusPoints = new List<double[]>();
            foreach (double[] point in torusPoints)
            {
                double[] rotatedPoint = projectionMatrix.RotationY(point, angleConverted);
                rotatedTorusPoints.Add(rotatedPoint);
            }

            // Project torus points onto 2D plane
            List<PointF> projectedTorusPoints = new List<PointF>();
            foreach (double[] point in rotatedTorusPoints)
            {
                double[] projectedPoint = projectionMatrix.multiply(point, 3);
                PointF projectedPointF = new PointF((float)(projectedPoint[0] * 100), (float)(projectedPoint[1] * 100));
                projectedTorusPoints.Add(projectedPointF);
            }

            // Draw torus
            //for (int i = 0; i < torusDetail; i++)
            //{
                //for (int j = 0; j < torusDetail; j++)
                //{
                    //int p1 = i * torusDetail + j;
                    //int p2 = (i + 1) % torusDetail * torusDetail + j;
                    //int p3 = (i + 1) % torusDetail * torusDetail + (j + 1) % torusDetail;
                    //int p4 = i * torusDetail + (j + 1) % torusDetail;

                    //Render(projectedTorusPoints[p1], projectedTorusPoints[p2], 0);
                    //Render(projectedTorusPoints[p2], projectedTorusPoints[p3], 0);
                    //Render(projectedTorusPoints[p3], projectedTorusPoints[p4], 0);
                    //Render(projectedTorusPoints[p4], projectedTorusPoints[p1], 0);
                //}
            //}
        }
        private void timer3_Tick(object sender, EventArgs e)
        {
            angle -= 1;
            angleConverted = angle * (Math.PI / 180);
            InitializePictureBox(width, height);

            //Generate CONE Points
            double Coneradius = 1.5;
            double Coneheight = 2.5;
            int coneDetail = 50;
            List<double[]> conePoints = new List<double[]>();

            for (int i = 0; i <= coneDetail; i++)
            {
                double angle = 2 * Math.PI * (double)i / coneDetail;
                double x = Coneradius * (1 - (double)i / coneDetail) * Math.Cos(angle);
                double y = Coneradius * (1 - (double)i / coneDetail) * Math.Sin(angle);
                double z = Coneheight * ((double)i / coneDetail) - Coneheight / 2;

                double[] point = new double[] { x, y, z };
                conePoints.Add(point);
            }
            //CONE?
            List<double[]> rotatedConePoints = new List<double[]>();
            foreach (double[] point in conePoints)
            {
                double[] rotatedConePoint = projectionMatrix.rotationZ(point, angleConverted);
                rotatedConePoints.Add(rotatedConePoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedConePoints = new List<PointF>();
            foreach (double[] point in rotatedConePoints)
            {
                double[] projectedConePoint = projectionMatrix.multiply(point, 3);
                PointF projectedConePointF = new PointF((float)(projectedConePoint[0] * 100), (float)(projectedConePoint[1] * 100));
                projectedConePoints.Add(projectedConePointF);
            }
            //DrawCone
            //for (int i = 0; i < conePoints.Count; i++)
            //{
                //int p1 = i;
                //int p2 = (i + 1) % conePoints.Count;
                //int p3 = conePoints.Count - 1;

                //Render(projectedConePoints[p1], projectedConePoints[p2], 0);
                //Render(projectedConePoints[p2], projectedConePoints[p3], 0);
                //Render(projectedConePoints[p3], projectedConePoints[p1], 0);

            //}


            //Generate Cylinder Points

            double Cylinderradius = 1.5;
            double Cylinderheight = 3.0;
            int cylinderDetail = 50;
            List<double[]> cylinderPoints = new List<double[]>();

            // Generar los puntos de la superficie curva del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);

                for (int j = 0; j <= cylinderDetail; j++)
                {
                    double z = Cylinderheight * (double)j / cylinderDetail - Cylinderheight / 2.0;

                    double[] point = new double[] { x, y, z };
                    cylinderPoints.Add(point);
                }
            }

            // Generar los puntos del disco inferior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = -Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            // Generar los puntos del disco superior del cilindro
            for (int i = 0; i <= cylinderDetail; i++)
            {
                double theta = 2 * Math.PI * (double)(i - 1) / cylinderDetail;
                double x = Cylinderradius * Math.Cos(theta);
                double y = Cylinderradius * Math.Sin(theta);
                double z = Cylinderheight / 2.0;

                double[] point = new double[] { x, y, z };
                cylinderPoints.Add(point);
            }

            //CYLINDER?
            List<double[]> rotatedCylinderPoints = new List<double[]>();
            foreach (double[] point in cylinderPoints)
            {
                double[] rotatedCylinderPoint = projectionMatrix.rotationZ(point, angleConverted);
                rotatedCylinderPoints.Add(rotatedCylinderPoint);
            }
            // Project CONE points onto 2D plane
            List<PointF> projectedCylinderPoints = new List<PointF>();
            foreach (double[] point in rotatedCylinderPoints)
            {
                double[] projectedCylinderPoint = projectionMatrix.multiply(point, 3);
                PointF projectedCylinderPointF = new PointF((float)(projectedCylinderPoint[0] * 100), (float)(projectedCylinderPoint[1] * 100));
                projectedCylinderPoints.Add(projectedCylinderPointF);
            }
            //DrawCylinder
            //for (int i = 0; i < cylinderDetail; i++)
            //{
            //for (int j = 0; j < cylinderDetail; j++)
            //{
            //int p1 = i * (cylinderDetail + 1) + j;
            //int p2 = p1 + 1;
            //int p3 = (i + 1) * (cylinderDetail + 1) + j;
            //int p4 = p3 + 1;

            //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p3], 0);
            //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p2], 0);
            //Render(projectedCylinderPoints[p2], projectedCylinderPoints[p3], 0);
            //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);

            //if (j == 0)
            //{
            //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2], 0);
            //Render(projectedCylinderPoints[p2], projectedCylinderPoints[p2 + cylinderDetail], 0);
            //Render(projectedCylinderPoints[p1], projectedCylinderPoints[p2 + cylinderDetail], 0);
            //Render(projectedCylinderPoints[p2 + cylinderDetail], projectedCylinderPoints[p1 + cylinderDetail], 0);
            //}
            //else if (j == cylinderDetail - 1)
            //{
            //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4], 0);
            //Render(projectedCylinderPoints[p4], projectedCylinderPoints[p4 + cylinderDetail], 0);
            //Render(projectedCylinderPoints[p3], projectedCylinderPoints[p4 + cylinderDetail], 0);
            //Render(projectedCylinderPoints[p4 + cylinderDetail], projectedCylinderPoints[p3 + cylinderDetail], 0);
            //}
            //}
            //}


            // Generate SPHERE Points
            double radius = 1.5;
            int sphereDetail = 50;
            List<double[]> spherePoints = new List<double[]>();

            for (int i = 0; i <= sphereDetail; i++)
            {
                double lat = Math.PI * (-0.5 + (double)(i - 1) / sphereDetail);
                double z = radius * Math.Sin(lat);
                double xy = radius * Math.Cos(lat);

                for (int j = 0; j <= sphereDetail; j++)
                {
                    double lng = 2 * Math.PI * (double)(j - 1) / sphereDetail;
                    double x = xy * Math.Cos(lng);
                    double y = xy * Math.Sin(lng);

                    double[] point = new double[] { x, y, z };
                    spherePoints.Add(point);
                }
            }

            //SPHERE?
            List<double[]> rotatedSpherePoints = new List<double[]>();
            foreach (double[] point in spherePoints)
            {
                double[] rotatedSpherePoint = projectionMatrix.rotationZ(point, angleConverted);
                rotatedSpherePoints.Add(rotatedSpherePoint);
            }
            // Project SPHERE? points onto 2D plane
            List<PointF> projectedSpherePoints = new List<PointF>();
            foreach (double[] point in rotatedSpherePoints)
            {
                double[] projectedSpherePoint = projectionMatrix.multiply(point, 3);
                PointF projectedSpherePointF = new PointF((float)(projectedSpherePoint[0] * 100), (float)(projectedSpherePoint[1] * 100));
                projectedSpherePoints.Add(projectedSpherePointF);
            }
            //DrawSphere
            //for (int i = 0; i < sphereDetail; i++)
            //{
            //for (int j = 0; j < sphereDetail; j++)
            //{
            //int p1 = i * sphereDetail + j;
            //int p2 = (i + 1) % sphereDetail * sphereDetail + j;
            //int p3 = (i + 1) % sphereDetail * sphereDetail + (j + 1) % sphereDetail;
            //int p4 = i * sphereDetail + (j + 1) % sphereDetail;

            //Render(projectedSpherePoints[p1], projectedSpherePoints[p2], 0);
            //Render(projectedSpherePoints[p2], projectedSpherePoints[p3], 0);
            //Render(projectedSpherePoints[p3], projectedSpherePoints[p4], 0);
            //Render(projectedSpherePoints[p4], projectedSpherePoints[p1], 0);
            //}
            //}
            // Generate torus points
            double R = 1.5;
            double r = 0.5;
            int torusDetail = 50;
            List<double[]> torusPoints = new List<double[]>();
            for (int i = 0; i < torusDetail; i++)
            {
                double theta = i * 2 * Math.PI / torusDetail;
                for (int j = 0; j < torusDetail; j++)
                {
                    double phi = j * 2 * Math.PI / torusDetail;
                    double x = (R + r * Math.Cos(phi)) * Math.Cos(theta);
                    double y = (R + r * Math.Cos(phi)) * Math.Sin(theta);
                    double z = r * Math.Sin(phi);
                    double[] point = new double[] { x, y, z };
                    torusPoints.Add(point);
                }
            }

            // Rotate torus points around X-axis
            List<double[]> rotatedTorusPoints = new List<double[]>();
            foreach (double[] point in torusPoints)
            {
                double[] rotatedPoint = projectionMatrix.rotationZ(point, angleConverted);
                rotatedTorusPoints.Add(rotatedPoint);
            }

            // Project torus points onto 2D plane
            List<PointF> projectedTorusPoints = new List<PointF>();
            foreach (double[] point in rotatedTorusPoints)
            {
                double[] projectedPoint = projectionMatrix.multiply(point, 3);
                PointF projectedPointF = new PointF((float)(projectedPoint[0] * 100), (float)(projectedPoint[1] * 100));
                projectedTorusPoints.Add(projectedPointF);
            }


            // Draw torus
            for (int i = 0; i < torusDetail; i++)
            {
                for (int j = 0; j < torusDetail; j++)
                {
                    int p1 = i * torusDetail + j;
                    int p2 = (i + 1) % torusDetail * torusDetail + j;
                    int p3 = (i + 1) % torusDetail * torusDetail + (j + 1) % torusDetail;
                    int p4 = i * torusDetail + (j + 1) % torusDetail;

                    //Render(projectedTorusPoints[p1], projectedTorusPoints[p2], 0);
                    //Render(projectedTorusPoints[p2], projectedTorusPoints[p3], 0);
                    FillTriangle(projectedTorusPoints[p1], projectedTorusPoints[p2], projectedTorusPoints[p3], Color.Green);
                    //Render(projectedTorusPoints[p3], projectedTorusPoints[p4], 0);
                    FillTriangle(projectedTorusPoints[p3], projectedTorusPoints[p4], projectedTorusPoints[p1], Color.Green);
                    //Render(projectedTorusPoints[p4], projectedTorusPoints[p1], 0);
                }
            }
        }

        public Form1()
        {
            InitializeComponent();
            width = pictureBox1.Width;
            height = pictureBox1.Height;
            wMid = width / 2;
            hMid = height / 2;
            origen = new Point(wMid, hMid);
            InitializePictureBox(width, height);
            angleConverted = angle * (Math.PI / 180);

        }

        private void InitializePictureBox(int width, int height)
        {
            bmp = new Bitmap(width, height);
            pictureBox1.Image = bmp;
            g = Graphics.FromImage(bmp);
            l1 = new Point(origen.X, 0);
            l2 = new Point(origen.X, height);
            l3 = new Point(0, origen.Y);
            l4 = new Point(width, origen.Y);
            g.DrawLine(Pens.Pink, l1, l2);
            g.DrawLine(Pens.Pink, l3, l4);
           
        }

        private void FillTriangle(PointF a, PointF b, PointF c, Color color)
        {
            using (SolidBrush brush = new SolidBrush(color))
            {
                PointF aOrigen = a;
                PointF bOrigen = b;
                PointF cOrigen = c;

                // Apply rotation to points in Cartesian coordinates
                PointF aRota = new PointF(
                    (float)(aOrigen.X * Math.Cos(angle) - aOrigen.Y * Math.Sin(angle)),
                    (float)(aOrigen.X * Math.Sin(angle) + aOrigen.Y * Math.Cos(angle))
                );
                PointF bRota = new PointF(
               (float)(bOrigen.X * Math.Cos(angle) - bOrigen.Y * Math.Sin(angle)),
               (float)(bOrigen.X * Math.Sin(angle) + bOrigen.Y * Math.Cos(angle))
           );
                PointF cRota = new PointF(
            (float)(cOrigen.X * Math.Cos(angle) - cOrigen.Y * Math.Sin(angle)),
            (float)(cOrigen.X * Math.Sin(angle) + cOrigen.Y * Math.Cos(angle))
        );
                // Translate points to the new origin
                PointF aTransla = new PointF(origen.X + aRota.X, origen.Y - aRota.Y);
                PointF bTransla = new PointF(origen.X + bRota.X, origen.Y - bRota.Y);
                PointF cTransla = new PointF(origen.X + cRota.X, origen.Y - cRota.Y);

                PointF[] points = new PointF[] { aTransla, bTransla, cTransla };
                g.FillPolygon(brush, points);
            }
        }

        private void Render(PointF a, PointF b, double angle)
        {
            PointF aOrig = a;
            PointF bOrig = b;

            // Apply rotation to points in Cartesian coordinates
            PointF aRot = new PointF(
                (float)(aOrig.X * Math.Cos(angle) - aOrig.Y * Math.Sin(angle)),
                (float)(aOrig.X * Math.Sin(angle) + aOrig.Y * Math.Cos(angle))
            );
            PointF bRot = new PointF(
                (float)(bOrig.X * Math.Cos(angle) - bOrig.Y * Math.Sin(angle)),
                (float)(bOrig.X * Math.Sin(angle) + bOrig.Y * Math.Cos(angle))
            );

            // Translate points to the new origin
            PointF aTrans = new PointF(origen.X + aRot.X, origen.Y - aRot.Y);
            PointF bTrans = new PointF(origen.X + bRot.X, origen.Y - bRot.Y);

            // Draw line
            g.DrawLine(Pens.MediumTurquoise, aTrans, bTrans);

            pictureBox1.Invalidate();
        }
    }
}
