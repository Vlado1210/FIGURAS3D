﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Numerics;

namespace cubo3d_el_bueno
{
    public class Cube
    {
        public Cube(Vector3 P1, Vector3 P2, Vector3 P3, Vector3 P4, Vector3 P5, Vector3 P6, Vector3 P7, Vector3 P8)
        {

        }
    }
}
