﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace cubo3d_el_bueno
{
    public class Scene
    {
        public List<Figure> Figures;
        public Scene()
        {
            Figures = new List<Figure>();
        }

    }
}
